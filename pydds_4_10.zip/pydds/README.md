# PyDDS Package Utilities

## Setup
- install protobuf>=3.9.6
```
$ python3 -m pip list | grep protobuf
protobuf      3.17.3

```
