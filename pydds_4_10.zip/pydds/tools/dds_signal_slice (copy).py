import os
dds_dir=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
python_root=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import sys
sys.path.append(dds_dir)
sys.path.append(python_root)
sys.path.append(os.path.join(python_root, "messages"))
from util import RecorcParser
from visio_conf import dict_topic
from pydds.bag import Bag
# inputs=sys.argv[1::]
inputs = ["/home/nio/Videos/20230331T190552.SOC1/_record", "np/debug/dgb_aeb_strtg.carInfo.brkStatus", 1000000000]
try:
    dir_path=inputs[0]
    signal=inputs[1]
    interval=int(inputs[2])
except Exception as e:
    print(e)
    raise("Usage: python3 dds_cut.py record_dir target_time(ns) interval(ns)")

record_parser = RecorcParser(dict_topic, -1, 1e20)
info = record_parser.Parser(dir_path, "pb_msg")
signal = signal.split('.')
info = info[signal[0]]
last_signal = False
signal_change_times = []
for t in range(len(info)):
	timestamp = info[t][0]
	info_ = info[t][1]
	for i in range(1, len(signal)):
		info_ = getattr(info_, signal[i], None)
	if t == 0:
		last_signal = info_
	if last_signal != info_:
		last_signal = info_
		signal_change_times.append(timestamp)

if not os.path.exists(os.path.join(dir_path, "slice_interval_record")):
	os.mkdir(os.path.join(dir_path, "slice_interval_record"))

if len(signal_change_times) == 0:
	exit(0)

cur_file_index = 0
for path in os.listdir(dir_path):
	if '.dat' not in path:
			continue
	try:
		bag=Bag(os.path.join(dir_path, path))
	except:
		continue


	cur_timestamp_index = 0
	cur_timestamp_path = os.path.join(dir_path, "slice_interval_record/", \
		str(signal_change_times[cur_timestamp_index]))
	if not os.path.exists(cur_timestamp_path):
		os.mkdir(cur_timestamp_path)
	f=open(cur_timestamp_path+"/"+os.path.basename(path),'wb')
	start_t = signal_change_times[cur_timestamp_index] - interval/2
	end_t = signal_change_times[cur_timestamp_index] + interval/2

	while True:
		msg, fsize, recv_ts, send_ts, recv_ts_ptp, send_ts_ptp = bag.read()
		if msg:
			if bag.current_timestamp>=start_t and bag.current_timestamp<=end_t:
				print("adding")
				f.write(recv_ts_ptp.to_bytes(8,"little"))
				f.write(send_ts_ptp.to_bytes(8,"little"))
				f.write(recv_ts.to_bytes(8,"little"))
				f.write(send_ts.to_bytes(8,"little"))
				f.write(fsize.to_bytes(8,"little"))
				f.write(msg.SerializeToString())
			elif bag.current_timestamp > end_t:
				f.close()
				cur_timestamp_index += 1
				if(len(signal_change_times) > cur_timestamp_index):
					cur_timestamp_path = os.path.join(dir_path, "slice_interval_record/",\
						str(signal_change_times[cur_timestamp_index]))
					if not os.path.exists(cur_timestamp_path):
						os.mkdir(cur_timestamp_path)
					f=open(cur_timestamp_path+"/"+os.path.basename(path),'wb+')
					start_t = signal_change_times[cur_timestamp_index] - interval/2
					end_t = signal_change_times[cur_timestamp_index] + interval/2
		else:
			break
